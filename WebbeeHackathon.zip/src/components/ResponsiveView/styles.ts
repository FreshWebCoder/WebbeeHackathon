import { StyleSheet } from 'react-native';

export default StyleSheet.create({
  item: {
    padding: 8
  },
});
